@file:OptIn(ExperimentalMaterial3Api::class)

// غيّر السطر ده لاسم الـ package بتاعك (نفس اللي في ملفك القديم)
package com.example.wallet

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// =====================================================
// الألوان والثيم (عدّل الألوان من هنا)
// =====================================================
val Green = Color(0xFF16A34A)   // دخل / ممتاز
val Red = Color(0xFFDC2626)     // مصروف / خطر
val Amber = Color(0xFFF59E0B)   // دين عليّ / تحذير
val Blue = Color(0xFF2563EB)    // دين ليّ
val HeaderStart = Color(0xFF0F766E)
val HeaderEnd = Color(0xFF14A38F)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF042F2E),
    secondary = Color(0xFFF59E0B),
    background = Color(0xFFF2F6F5),
    onBackground = Color(0xFF0F1F1D),
    surface = Color.White,
    onSurface = Color(0xFF0F1F1D),
    surfaceVariant = Color(0xFFE3EDEB),
    onSurfaceVariant = Color(0xFF475B58),
    outline = Color(0xFFB6C8C5),
    error = Red
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF2DD4BF),
    onPrimary = Color(0xFF003731),
    primaryContainer = Color(0xFF134E4A),
    onPrimaryContainer = Color(0xFFCCFBF1),
    secondary = Color(0xFFFBBF24),
    background = Color(0xFF0C1413),
    onBackground = Color(0xFFE2ECEA),
    surface = Color(0xFF16211F),
    onSurface = Color(0xFFE2ECEA),
    surfaceVariant = Color(0xFF22312F),
    onSurfaceVariant = Color(0xFFA9BDBA),
    outline = Color(0xFF3B4F4C),
    error = Color(0xFFF87171)
)

@Composable
fun WalletTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

val LocalCur = compositionLocalOf { "ج.م" }

@Composable
fun fmt(x: Double): String = String.format(Locale.US, "%,.2f", x) + " " + LocalCur.current

// =====================================================
// النموذج
// =====================================================
enum class Type(val label: String) {
    INCOME("دخل"),
    EXPENSE("مصروف"),
    DEBT_ME("دين عليّ"),     // أنا مدين لحد
    DEBT_OTHER("دين ليّ")    // حد مدين لي
}

fun Type.color() = when (this) {
    Type.INCOME -> Green
    Type.EXPENSE -> Red
    Type.DEBT_ME -> Amber
    Type.DEBT_OTHER -> Blue
}

data class Tx(
    val id: Long,
    val type: Type,
    val amount: Double,
    val title: String,
    val category: String,
    val date: Long,
    val settled: Boolean
)

val ExpenseCats = listOf("أكل", "مواصلات", "فواتير", "ترفيه", "صحة", "تعليم", "ملابس", "أخرى")
val IncomeCats = listOf("راتب", "عمل حر", "هدية", "أخرى")
val Currencies = listOf("ج.م", "ر.س", "د.إ", "د.ك", "$")

// =====================================================
// قاعدة البيانات (أوفلاين - SQLite)
// =====================================================
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "wallet.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, " +
                "amount REAL, title TEXT, category TEXT, date INTEGER, settled INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE budgets(cat TEXT PRIMARY KEY, lim REAL)")
    }

    // الترقية من النسخة 1 بتحافظ على بياناتك القديمة
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        db.execSQL("CREATE TABLE IF NOT EXISTS budgets(cat TEXT PRIMARY KEY, lim REAL)")
    }

    fun all(): List<Tx> {
        val list = mutableListOf<Tx>()
        readableDatabase.rawQuery(
            "SELECT id,type,amount,title,category,date,settled FROM tx ORDER BY date DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    Tx(
                        c.getLong(0), Type.valueOf(c.getString(1)), c.getDouble(2),
                        c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5), c.getInt(6) == 1
                    )
                )
            }
        }
        return list
    }

    fun add(t: Type, amount: Double, title: String, cat: String) {
        val v = ContentValues().apply {
            put("type", t.name); put("amount", amount); put("title", title)
            put("category", cat); put("date", System.currentTimeMillis()); put("settled", 0)
        }
        writableDatabase.insert("tx", null, v)
    }

    fun update(id: Long, t: Type, amount: Double, title: String, cat: String) {
        val v = ContentValues().apply {
            put("type", t.name); put("amount", amount); put("title", title); put("category", cat)
        }
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("tx", "id=?", arrayOf(id.toString()))
    }

    fun setSettled(id: Long, s: Boolean) {
        val v = ContentValues().apply { put("settled", if (s) 1 else 0) }
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
    }

    fun budgets(): Map<String, Double> {
        val m = linkedMapOf<String, Double>()
        readableDatabase.rawQuery("SELECT cat,lim FROM budgets ORDER BY cat", null).use { c ->
            while (c.moveToNext()) m[c.getString(0)] = c.getDouble(1)
        }
        return m
    }

    fun setBudget(cat: String, lim: Double) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO budgets(cat,lim) VALUES(?,?)", arrayOf<Any>(cat, lim))
    }

    fun delBudget(cat: String) {
        writableDatabase.delete("budgets", "cat=?", arrayOf(cat))
    }

    fun clearAll() {
        writableDatabase.execSQL("DELETE FROM tx")
        writableDatabase.execSQL("DELETE FROM budgets")
    }
}

// =====================================================
// Activity
// =====================================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val db = Db(this)
        setContent {
            WalletTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    WalletApp(db)
                }
            }
        }
    }
}

fun exportCsv(ctx: Context, items: List<Tx>) {
    fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    val df = SimpleDateFormat("yyyy/MM/dd", Locale.US)
    val sb = StringBuilder("النوع,المبلغ,الوصف,التصنيف,التاريخ,مسدد\n")
    items.forEach {
        sb.append("${q(it.type.label)},${it.amount},${q(it.title)},${q(it.category)},${df.format(Date(it.date))},${if (it.settled) "نعم" else "لا"}\n")
    }
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "بيانات المحفظة")
        putExtra(Intent.EXTRA_TEXT, sb.toString())
    }
    ctx.startActivity(Intent.createChooser(i, "تصدير البيانات"))
}

// =====================================================
// التطبيق الرئيسي
// =====================================================
@Composable
fun WalletApp(db: Db) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }

    var items by remember { mutableStateOf(db.all()) }
    var budgets by remember { mutableStateOf(db.budgets()) }
    var cur by remember { mutableStateOf(prefs.getString("cur", "ج.م") ?: "ج.م") }
    var tab by remember { mutableStateOf(0) }
    var offset by remember { mutableStateOf(0) }
    var showAll by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var showBudget by remember { mutableStateOf(false) }

    fun refresh() { items = db.all(); budgets = db.budgets() }

    val keyFmt = remember { SimpleDateFormat("yyyy-MM", Locale.US) }
    val labelFmt = remember { SimpleDateFormat("MMMM yyyy", Locale.forLanguageTag("ar")) }
    val cal = Calendar.getInstance().apply { add(Calendar.MONTH, offset) }
    val key = keyFmt.format(cal.time)
    val monthItems = items.filter { keyFmt.format(Date(it.date)) == key }
    val period = if (showAll) items else monthItems

    val income = period.filter { it.type == Type.INCOME }.sumOf { it.amount }
    val expense = period.filter { it.type == Type.EXPENSE }.sumOf { it.amount }
    val totalBalance = items.filter { it.type == Type.INCOME }.sumOf { it.amount } -
        items.filter { it.type == Type.EXPENSE }.sumOf { it.amount }

    val days = if (offset == 0) cal.get(Calendar.DAY_OF_MONTH) else cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    CompositionLocalProvider(LocalCur provides cur) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { editing = null; showDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.navigationBarsPadding()
                ) { Text("+", style = MaterialTheme.typography.headlineMedium) }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Header(
                    balance = totalBalance, income = income, expense = expense,
                    label = labelFmt.format(cal.time), all = showAll,
                    onPrev = { offset-- }, onNext = { offset++ },
                    onToggleAll = { showAll = !showAll }
                )
                TabRow(
                    selectedTabIndex = tab,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    listOf("الملخص", "المعاملات", "الميزانية", "المزيد").forEachIndexed { i, s ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) })
                    }
                }
                when (tab) {
                    0 -> SummaryTab(period, items, days, showAll)
                    1 -> TxTab(
                        period, db, ::refresh,
                        onEdit = { editing = it; showDialog = true }
                    )
                    2 -> BudgetTab(
                        budgets,
                        (if (showAll) items.filter { keyFmt.format(Date(it.date)) == keyFmt.format(Date()) } else monthItems)
                            .filter { it.type == Type.EXPENSE }
                            .groupBy { it.category.ifBlank { "غير مصنف" } }
                            .mapValues { e -> e.value.sumOf { it.amount } },
                        onAdd = { showBudget = true },
                        onDelete = { db.delBudget(it); refresh() }
                    )
                    else -> MoreTab(
                        cur = cur,
                        onCur = { cur = it; prefs.edit().putString("cur", it).apply() },
                        onExport = { exportCsv(ctx, items) },
                        onClear = { db.clearAll(); refresh() }
                    )
                }
            }
        }

        if (showDialog) {
            TxDialog(
                initial = editing,
                onDismiss = { showDialog = false },
                onSave = { t, a, title, cat ->
                    val e = editing
                    if (e == null) db.add(t, a, title, cat) else db.update(e.id, t, a, title, cat)
                    refresh(); showDialog = false
                }
            )
        }
        if (showBudget) {
            BudgetDialog(
                onDismiss = { showBudget = false },
                onSave = { c, l -> db.setBudget(c, l); refresh(); showBudget = false }
            )
        }
    }
}

// =====================================================
// الهيدر (الخلفية المتدرجة + الرصيد + اختيار الشهر)
// =====================================================
@Composable
fun Header(
    balance: Double, income: Double, expense: Double, label: String, all: Boolean,
    onPrev: () -> Unit, onNext: () -> Unit, onToggleAll: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.linearGradient(listOf(HeaderStart, HeaderEnd)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text("محفظتي", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onPrev, enabled = !all) {
                Text("→ السابق", color = Color.White.copy(alpha = if (all) 0.35f else 1f))
            }
            TextButton(onClick = onToggleAll) {
                Text(if (all) "كل الفترات" else label, color = Color.White, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onNext, enabled = !all) {
                Text("التالي ←", color = Color.White.copy(alpha = if (all) 0.35f else 1f))
            }
        }
        Text("الرصيد الكلي", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
        Text(fmt(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniStat("الدخل", fmt(income), Modifier.weight(1f))
            MiniStat("المصروف", fmt(expense), Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(label, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
        Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val shape = RoundedCornerShape(18.dp)
    val elev = CardDefaults.cardElevation(defaultElevation = 1.dp)
    if (onClick == null) {
        Card(modifier = modifier, shape = shape, colors = colors, elevation = elev) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, elevation = elev) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

// =====================================================
// تبويب الملخص
// =====================================================
@Composable
fun SummaryTab(period: List<Tx>, all: List<Tx>, days: Int, isAll: Boolean) {
    val income = period.filter { it.type == Type.INCOME }.sumOf { it.amount }
    val expense = period.filter { it.type == Type.EXPENSE }.sumOf { it.amount }
    val ratio = if (income > 0) (expense / income).toFloat() else if (expense > 0) 1f else 0f
    val (ratioColor, ratioMsg) = when {
        ratio < 0.5f -> Green to "ممتاز 👌 صرفك أقل من نص دخلك"
        ratio < 0.8f -> Amber to "انتبه ⚠ صرفك بيقرب من دخلك"
        ratio <= 1f -> Red to "خطر 🚨 كل دخلك تقريبًا اتصرف"
        else -> Red to "🚨 صرفت أكتر من دخلك"
    }
    val saved = income - expense
    val savingRate = if (income > 0) (saved / income * 100).toInt() else 0

    val iOwe = all.filter { it.type == Type.DEBT_ME && !it.settled }.sumOf { it.amount }
    val owedToMe = all.filter { it.type == Type.DEBT_OTHER && !it.settled }.sumOf { it.amount }

    val byCat = period.filter { it.type == Type.EXPENSE }
        .groupBy { it.category.ifBlank { "غير مصنف" } }
        .mapValues { e -> e.value.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }
    val biggest = period.filter { it.type == Type.EXPENSE }.maxByOrNull { it.amount }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("نسبة الصرف من الدخل", fontWeight = FontWeight.SemiBold)
                    Text("${(ratio * 100).toInt()}%", color = ratioColor, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { ratio.coerceIn(0f, 1f) },
                    color = ratioColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))
                )
                Spacer(Modifier.height(8.dp))
                Text(ratioMsg, color = ratioColor, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("المدخرات", fmt(saved), if (saved >= 0) Green else Red, Modifier.weight(1f))
                StatCard("نسبة الادخار", "$savingRate%", MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("ديون عليّ", fmt(iOwe), Amber, Modifier.weight(1f))
                StatCard("مستحقات ليّ", fmt(owedToMe), Blue, Modifier.weight(1f))
            }
        }
        if (!isAll && expense > 0) {
            item {
                StatCard("متوسط الصرف اليومي", fmt(expense / days), MaterialTheme.colorScheme.onSurface, Modifier.fillMaxWidth())
            }
        }
        if (biggest != null) {
            item {
                StatCard(
                    "أكبر مصروف",
                    "${biggest.title.ifBlank { biggest.category.ifBlank { "—" } }}: ${fmt(biggest.amount)}",
                    Red, Modifier.fillMaxWidth()
                )
            }
        }
        if (byCat.isNotEmpty()) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("المصروفات حسب التصنيف", fontWeight = FontWeight.SemiBold)
                    byCat.forEach { (cat, sum) ->
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(cat); Text(fmt(sum), fontWeight = FontWeight.Medium)
                        }
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { if (expense > 0) (sum / expense).toFloat() else 0f },
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
        }
        if (period.isEmpty()) {
            item {
                Text(
                    "مفيش معاملات في الفترة دي. اضغط + للإضافة.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    AppCard(modifier) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor, fontWeight = FontWeight.Bold)
    }
}

// =====================================================
// تبويب المعاملات (بحث + فلترة + تعديل)
// =====================================================
@Composable
fun TxTab(period: List<Tx>, db: Db, refresh: () -> Unit, onEdit: (Tx) -> Unit) {
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<Type?>(null) }
    val df = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
    val shown = period.filter {
        (filter == null || it.type == filter) &&
            (q.isBlank() || it.title.contains(q, true) || it.category.contains(q, true))
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("بحث") }, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("الكل") })
                Type.values().forEach {
                    FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it.label) })
                }
            }
        }
        if (shown.isEmpty()) {
            item { Text("لا توجد معاملات", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
        }
        items(shown, key = { it.id }) { t ->
            AppCard(Modifier.fillMaxWidth(), onClick = { onEdit(t) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(t.type.color()))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title.ifBlank { t.type.label }, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${t.type.label} • ${t.category.ifBlank { "—" }} • ${df.format(Date(t.date))}" +
                                if (t.settled) " • ✔ مسدد" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    val sign = if (t.type == Type.INCOME || t.type == Type.DEBT_OTHER) "+" else "-"
                    Text("$sign${fmt(t.amount)}", color = t.type.color(), fontWeight = FontWeight.Bold)
                }
                Row {
                    if (t.type == Type.DEBT_ME || t.type == Type.DEBT_OTHER) {
                        TextButton(onClick = { db.setSettled(t.id, !t.settled); refresh() }) {
                            Text(if (t.settled) "إلغاء التسديد" else "تم التسديد")
                        }
                    }
                    TextButton(onClick = { onEdit(t) }) { Text("تعديل") }
                    TextButton(onClick = { db.delete(t.id); refresh() }) {
                        Text("حذف", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// =====================================================
// تبويب الميزانية الشهرية
// =====================================================
@Composable
fun BudgetTab(
    budgets: Map<String, Double>, spent: Map<String, Double>,
    onAdd: () -> Unit, onDelete: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("+ إضافة / تعديل ميزانية تصنيف")
            }
        }
        if (budgets.isEmpty()) {
            item {
                Text(
                    "حدد حد شهري لكل تصنيف (مثلًا أكل 2000) وهتتنبه لما تقرب منه.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(budgets.toList(), key = { it.first }) { (cat, limit) ->
            val s = spent[cat] ?: 0.0
            val r = if (limit > 0) (s / limit).toFloat() else 0f
            val c = when { r < 0.8f -> Green; r < 1f -> Amber; else -> Red }
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(cat, fontWeight = FontWeight.SemiBold)
                    Text("${(r * 100).toInt()}%", color = c, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { r.coerceIn(0f, 1f) }, color = c,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "صرفت ${fmt(s)} من ${fmt(limit)}" +
                        if (r >= 1f) " — تجاوزت الميزانية!" else "",
                    style = MaterialTheme.typography.bodySmall, color = c
                )
                TextButton(onClick = { onDelete(cat) }) {
                    Text("حذف الميزانية", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

// =====================================================
// تبويب المزيد (العملة + تصدير + مسح)
// =====================================================
@Composable
fun MoreTab(cur: String, onCur: (String) -> Unit, onExport: () -> Unit, onClear: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("العملة", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Currencies.forEach { FilterChip(selected = cur == it, onClick = { onCur(it) }, label = { Text(it) }) }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("تصدير البيانات", fontWeight = FontWeight.SemiBold)
                Text(
                    "ابعت كل معاملاتك كملف CSV نصي (واتساب، إيميل، Drive...) يفتح في Excel.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = onExport, shape = RoundedCornerShape(12.dp)) { Text("تصدير") }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("مسح كل البيانات", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                Text(
                    "هيمسح كل المعاملات والميزانيات من الجهاز نهائيًا.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { confirm = true }, shape = RoundedCornerShape(12.dp)) {
                    Text("مسح", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        item {
            Text(
                "التطبيق شغال أوفلاين بالكامل، وبياناتك محفوظة على جهازك فقط.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(4.dp)
            )
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("متأكد؟") },
            text = { Text("كل البيانات هتتمسح ومينفعش ترجع.") },
            confirmButton = {
                TextButton(onClick = { onClear(); confirm = false }) {
                    Text("امسح", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}

// =====================================================
// نافذة إضافة / تعديل معاملة
// =====================================================
@Composable
fun TxDialog(initial: Tx?, onDismiss: () -> Unit, onSave: (Type, Double, String, String) -> Unit) {
    var type by remember { mutableStateOf(initial?.type ?: Type.EXPENSE) }
    var amount by remember {
        mutableStateOf(
            initial?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""
        )
    }
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var cat by remember { mutableStateOf(initial?.category ?: "") }
    val isDebt = type == Type.DEBT_ME || type == Type.DEBT_OTHER

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "إضافة معاملة" else "تعديل المعاملة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Type.values().forEach {
                        FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it.label) })
                    }
                }
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it }, label = { Text("المبلغ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                )
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(if (isDebt) "اسم الشخص" else "الوصف") }, singleLine = true
                )
                if (!isDebt) {
                    val cats = if (type == Type.INCOME) IncomeCats else ExpenseCats
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        cats.forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                        }
                    }
                    OutlinedTextField(
                        value = cat, onValueChange = { cat = it },
                        label = { Text("التصنيف") }, singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.replace(",", ".").toDoubleOrNull()
                if (a != null && a > 0) onSave(type, a, title.trim(), if (isDebt) "" else cat.trim())
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// =====================================================
// نافذة الميزانية
// =====================================================
@Composable
fun BudgetDialog(onDismiss: () -> Unit, onSave: (String, Double) -> Unit) {
    var cat by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("ميزانية شهرية") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpenseCats.forEach { c ->
                        FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                    }
                }
                OutlinedTextField(
                    value = cat, onValueChange = { cat = it },
                    label = { Text("التصنيف") }, singleLine = true
                )
                OutlinedTextField(
                    value = limit, onValueChange = { limit = it }, label = { Text("الحد الشهري") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val l = limit.replace(",", ".").toDoubleOrNull()
                if (cat.isNotBlank() && l != null && l > 0) onSave(cat.trim(), l)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
