@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.wallet

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// =====================================================
// الألوان والثيم
// =====================================================
val Green = Color(0xFF16A34A)
val Red = Color(0xFFDC2626)
val Amber = Color(0xFFF59E0B)
val Blue = Color(0xFF2563EB)
val HeaderStart = Color(0xFF0F766E)
val HeaderEnd = Color(0xFF14A38F)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF042F2E),
    secondary = Color(0xFFF59E0B),
    background = Color(0xFFF2F6F5),
    onBackground = Color(0xFF0F1F1D),
    surface = Color.White,
    onSurface = Color(0xFF0F1F1D),
    surfaceVariant = Color(0xFFE3EDEB),
    onSurfaceVariant = Color(0xFF475B58),
    outline = Color(0xFFB6C8C5),
    error = Red
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF2DD4BF),
    onPrimary = Color(0xFF003731),
    primaryContainer = Color(0xFF134E4A),
    onPrimaryContainer = Color(0xFFCCFBF1),
    secondary = Color(0xFFFBBF24),
    background = Color(0xFF0C1413),
    onBackground = Color(0xFFE2ECEA),
    surface = Color(0xFF16211F),
    onSurface = Color(0xFFE2ECEA),
    surfaceVariant = Color(0xFF22312F),
    onSurfaceVariant = Color(0xFFA9BDBA),
    outline = Color(0xFF3B4F4C),
    error = Color(0xFFF87171)
)

// mode: 0 تلقائي، 1 فاتح، 2 داكن
@Composable
fun WalletTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

val LocalCur = compositionLocalOf { "ج.س" }
val LocalDec = compositionLocalOf { true }

@Composable
fun fmt(x: Double): String =
    String.format(Locale.US, if (LocalDec.current) "%,.2f" else "%,.0f", x) + " " + LocalCur.current

// =====================================================
// النموذج
// =====================================================
enum class Type(val label: String) {
    INCOME("دخل"),
    EXPENSE("مصروف"),
    DEBT_ME("دين عليّ"),
    DEBT_OTHER("دين ليّ")
}

fun Type.color() = when (this) {
    Type.INCOME -> Green
    Type.EXPENSE -> Red
    Type.DEBT_ME -> Amber
    Type.DEBT_OTHER -> Blue
}

data class Tx(
    val id: Long,
    val type: Type,
    val amount: Double,
    val title: String,
    val category: String,
    val date: Long,
    val settled: Boolean
)

val ExpenseCats = listOf("أكل", "مواصلات", "فواتير", "ترفيه", "صحة", "تعليم", "ملابس", "أخرى")
val IncomeCats = listOf("راتب", "عمل حر", "هدية", "أخرى")

val Currencies = listOf(
    "ج.س" to "جنيه سوداني",
    "ج.م" to "جنيه مصري",
    "ر.س" to "ريال سعودي",
    "د.إ" to "درهم إماراتي",
    "د.ك" to "دينار كويتي",
    "$" to "دولار"
)
val ThemeLabels = listOf("تلقائي", "فاتح", "داكن")

// =====================================================
// قاعدة البيانات (أوفلاين - SQLite)
// =====================================================
class Db(private val ctx: Context, private val dbName: String) : SQLiteOpenHelper(ctx, dbName, null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, " +
                "amount REAL, title TEXT, category TEXT, date INTEGER, settled INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE budgets(cat TEXT PRIMARY KEY, lim REAL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        db.execSQL("CREATE TABLE IF NOT EXISTS budgets(cat TEXT PRIMARY KEY, lim REAL)")
    }

    // وقت آخر تعديل (للمزامنة)
    private fun meta() = ctx.getSharedPreferences("meta_$dbName", Context.MODE_PRIVATE)
    fun modified(): Long = meta().getLong("mod", 0L)
    fun setModified(t: Long) { meta().edit().putLong("mod", t).apply() }
    private fun touch() = setModified(System.currentTimeMillis())

    fun all(): List<Tx> {
        val list = mutableListOf<Tx>()
        readableDatabase.rawQuery(
            "SELECT id,type,amount,title,category,date,settled FROM tx ORDER BY date DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    Tx(
                        c.getLong(0), Type.valueOf(c.getString(1)), c.getDouble(2),
                        c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5), c.getInt(6) == 1
                    )
                )
            }
        }
        return list
    }

    fun add(t: Type, amount: Double, title: String, cat: String) {
        val v = ContentValues().apply {
            put("type", t.name); put("amount", amount); put("title", title)
            put("category", cat); put("date", System.currentTimeMillis()); put("settled", 0)
        }
        writableDatabase.insert("tx", null, v)
        touch()
    }

    fun update(id: Long, t: Type, amount: Double, title: String, cat: String) {
        val v = ContentValues().apply {
            put("type", t.name); put("amount", amount); put("title", title); put("category", cat)
        }
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
        touch()
    }

    fun delete(id: Long) {
        writableDatabase.delete("tx", "id=?", arrayOf(id.toString()))
        touch()
    }

    fun setSettled(id: Long, s: Boolean) {
        val v = ContentValues().apply { put("settled", if (s) 1 else 0) }
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
        touch()
    }

    fun budgets(): Map<String, Double> {
        val m = linkedMapOf<String, Double>()
        readableDatabase.rawQuery("SELECT cat,lim FROM budgets ORDER BY cat", null).use { c ->
            while (c.moveToNext()) m[c.getString(0)] = c.getDouble(1)
        }
        return m
    }

    fun setBudget(cat: String, lim: Double) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO budgets(cat,lim) VALUES(?,?)", arrayOf<Any>(cat, lim))
        touch()
    }

    fun delBudget(cat: String) {
        writableDatabase.delete("budgets", "cat=?", arrayOf(cat))
        touch()
    }

    fun clearAll() {
        writableDatabase.execSQL("DELETE FROM tx")
        writableDatabase.execSQL("DELETE FROM budgets")
        touch()
    }

    fun backupJson(): String {
        val arr = JSONArray()
        all().forEach {
            arr.put(
                JSONObject()
                    .put("type", it.type.name)
                    .put("amount", it.amount)
                    .put("title", it.title)
                    .put("category", it.category)
                    .put("date", it.date)
                    .put("settled", it.settled)
            )
        }
        val b = JSONObject()
        budgets().forEach { (k, v) -> b.put(k, v) }
        return JSONObject()
            .put("app", "wallet")
            .put("version", 1)
            .put("tx", arr)
            .put("budgets", b)
            .toString()
    }

    // ts: وقت التعديل المرتبط بالنسخة (لو جاية من السحابة)
    fun restore(json: String, ts: Long? = null): Boolean {
        return try {
            val root = JSONObject(json.trim())
            val arr = root.getJSONArray("tx")
            val bud = root.optJSONObject("budgets")
            val w = writableDatabase
            w.beginTransaction()
            try {
                w.execSQL("DELETE FROM tx")
                w.execSQL("DELETE FROM budgets")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val v = ContentValues().apply {
                        put("type", Type.valueOf(o.getString("type")).name)
                        put("amount", o.getDouble("amount"))
                        put("title", o.optString("title"))
                        put("category", o.optString("category"))
                        put("date", o.getLong("date"))
                        put("settled", if (o.optBoolean("settled")) 1 else 0)
                    }
                    w.insert("tx", null, v)
                }
                if (bud != null) {
                    val keys = bud.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        w.execSQL("INSERT OR REPLACE INTO budgets(cat,lim) VALUES(?,?)", arrayOf<Any>(k, bud.getDouble(k)))
                    }
                }
                w.setTransactionSuccessful()
            } finally {
                w.endTransaction()
            }
            setModified(ts ?: System.currentTimeMillis())
            true
        } catch (e: Exception) {
            false
        }
    }
}

// =====================================================
// الحساب المحلي (كلمة السر بتتخزن مشفّرة على الجهاز)
// =====================================================
object Local {
    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 10000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
    }

    fun save(p: SharedPreferences, user: String, uid: String, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("acct_user", user)
            .putString("acct_uid", uid)
            .putString("acct_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("acct_hash", hash(pw, salt))
            .apply()
    }

    fun verify(p: SharedPreferences, user: String, pw: String): Boolean {
        return try {
            if (p.getString("acct_user", "") != user) return false
            val salt = Base64.decode(p.getString("acct_salt", "") ?: "", Base64.NO_WRAP)
            hash(pw, salt) == p.getString("acct_hash", "")
        } catch (e: Exception) {
            false
        }
    }

    fun verifyAny(p: SharedPreferences, pw: String) = verify(p, p.getString("acct_user", "") ?: "", pw)
}

fun startSession(p: SharedPreferences, user: String, uid: String) {
    p.edit().putString("user", user).putString("uid", uid).apply()
}

// كل حساب ليه ملف بيانات خاص بيه على الجهاز
fun dbNameFor(p: SharedPreferences, uid: String): String {
    val owner = p.getString("owner", null)
    if (owner == null) {
        p.edit().putString("owner", uid).apply()
        return "wallet.db"
    }
    return if (owner == uid) "wallet.db" else "wallet_" + uid.filter { it.isLetterOrDigit() } + ".db"
}

// =====================================================
// السحابة (Firebase عن طريق REST - من غير ملفات إعداد)
// =====================================================
object Cloud {
    private var idToken = ""
    private var expiresAt = 0L

    fun key(p: SharedPreferences) = (p.getString("cfg_key", "") ?: "").trim()
    fun pid(p: SharedPreferences) = (p.getString("cfg_pid", "") ?: "").trim()
    fun on(p: SharedPreferences) = key(p).isNotEmpty() && pid(p).isNotEmpty()
    fun clear() { idToken = ""; expiresAt = 0L }

    fun http(method: String, url: String, body: String?, token: String?, ctype: String = "application/json"): Pair<Int, String> {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            if (method == "PATCH") {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            } else {
                c.requestMethod = method
            }
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", ctype)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val s = if (code in 200..299) c.inputStream else c.errorStream
            val text = s?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            code to text
        } catch (e: Exception) {
            -1 to (e.message ?: "")
        }
    }

    fun authCall(p: SharedPreferences, kind: String, email: String, pass: String): Pair<Int, String> {
        val body = JSONObject().put("email", email).put("password", pass).put("returnSecureToken", true).toString()
        return http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:$kind?key=${key(p)}", body, null)
    }

    fun remember(p: SharedPreferences, j: JSONObject) {
        idToken = j.getString("idToken")
        expiresAt = System.currentTimeMillis() + j.getString("expiresIn").toLong() * 1000
        p.edit().putString("refresh", j.getString("refreshToken")).apply()
    }

    fun token(p: SharedPreferences): String? {
        if (idToken.isNotEmpty() && System.currentTimeMillis() < expiresAt - 60000) return idToken
        val rt = p.getString("refresh", "") ?: ""
        if (rt.isEmpty()) return null
        val (code, txt) = http(
            "POST", "https://securetoken.googleapis.com/v1/token?key=${key(p)}",
            "grant_type=refresh_token&refresh_token=$rt", null, "application/x-www-form-urlencoded"
        )
        if (code != 200) return null
        return try {
            val j = JSONObject(txt)
            idToken = j.getString("id_token")
            expiresAt = System.currentTimeMillis() + j.getString("expires_in").toLong() * 1000
            p.edit().putString("refresh", j.getString("refresh_token")).apply()
            idToken
        } catch (e: Exception) {
            null
        }
    }

    fun errMsg(txt: String): String {
        val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
        return when {
            m.startsWith("EMAIL_EXISTS") -> "اسم المستخدم مستخدم بالفعل، اختار اسم تاني"
            m.startsWith("EMAIL_NOT_FOUND") || m.startsWith("INVALID_PASSWORD") ||
                m.startsWith("INVALID_LOGIN_CREDENTIALS") -> "اسم المستخدم أو كلمة السر غلط"
            m.startsWith("WEAK_PASSWORD") -> "كلمة السر ضعيفة (6 حروف على الأقل)"
            m.startsWith("OPERATION_NOT_ALLOWED") -> "فعّل Email/Password في Firebase (Authentication)"
            m.contains("API key") -> "مفتاح الـ API غلط، راجع إعداد السحابة"
            m.startsWith("TOO_MANY_ATTEMPTS") -> "محاولات كتير، استنى شوية وجرب تاني"
            else -> m.take(120)
        }
    }

    private fun docUrl(p: SharedPreferences, uid: String) =
        "https://firestore.googleapis.com/v1/projects/${pid(p)}/databases/(default)/documents/users/$uid"

    // يرجّع (رسالة الحالة، هل البيانات المحلية اتغيّرت من السحابة)
    fun sync(p: SharedPreferences, db: Db): Pair<String, Boolean> {
        if (!on(p)) return "" to false
        val uid = p.getString("uid", "") ?: ""
        if (uid.isEmpty() || uid.startsWith("local_")) return "" to false
        val tok = token(p) ?: return "☁ غير متصل" to false

        if (db.modified() == 0L && db.all().isNotEmpty()) db.setModified(System.currentTimeMillis())

        val (code, txt) = http("GET", docUrl(p, uid), null, tok)
        if (code == -1) return "☁ غير متصل" to false
        var cloudTs = 0L
        var data: String? = null
        if (code == 200) {
            try {
                val f = JSONObject(txt).getJSONObject("fields")
                data = f.getJSONObject("data").getString("stringValue")
                cloudTs = f.getJSONObject("updatedAt").getString("integerValue").toLong()
            } catch (e: Exception) {
                return "☁ تعذر قراءة بيانات السحابة" to false
            }
        } else if (code != 404) {
            return "☁ خطأ في المزامنة ($code) - راجع قواعد Firestore" to false
        }

        val local = db.modified()
        if (data != null && cloudTs > local) {
            return if (db.restore(data, cloudTs)) "☁ تم تحميل بياناتك من السحابة" to true
            else "☁ تعذر قراءة بيانات السحابة" to false
        }
        if (local > cloudTs) {
            val body = JSONObject().put(
                "fields",
                JSONObject()
                    .put("data", JSONObject().put("stringValue", db.backupJson()))
                    .put("updatedAt", JSONObject().put("integerValue", local.toString()))
            ).toString()
            val (c2, _) = http(
                "PATCH", docUrl(p, uid) + "?updateMask.fieldPaths=data&updateMask.fieldPaths=updatedAt", body, tok
            )
            return if (c2 in 200..299) "☁ تمت المزامنة ✔" to false else "☁ تعذر الرفع ($c2)" to false
        }
        return "☁ البيانات محدّثة ✔" to false
    }
}

// تسجيل الدخول / إنشاء الحساب. يرجّع (نجح؟، اسم المستخدم أو رسالة الخطأ)
fun doAuth(p: SharedPreferences, signup: Boolean, username: String, pass: String): Pair<Boolean, String> {
    val u = username.trim().lowercase(Locale.US)
    if (!Regex("^[a-z0-9_]{3,20}$").matches(u)) {
        return false to "اسم المستخدم: حروف إنجليزية وأرقام و _ فقط (من 3 إلى 20)"
    }
    if (pass.length < 6) return false to "كلمة السر لازم تكون 6 حروف على الأقل"

    if (Cloud.on(p)) {
        val (code, txt) = Cloud.authCall(p, if (signup) "signUp" else "signInWithPassword", "$u@wallet.app", pass)
        if (code == 200) {
            val j = JSONObject(txt)
            val uid = j.getString("localId")
            Cloud.remember(p, j)
            Local.save(p, u, uid, pass)
            startSession(p, u, uid)
            return true to u
        }
        if (code == -1) {
            if (!signup && Local.verify(p, u, pass)) {
                startSession(p, u, p.getString("acct_uid", "") ?: "")
                return true to u
            }
            return false to "مفيش إنترنت. أول تسجيل دخول على الجهاز لازم يكون أونلاين."
        }
        return false to Cloud.errMsg(txt)
    }

    // وضع محلي (من غير سحابة)
    if (signup) {
        if (p.getString("acct_user", null) != null) return false to "فيه حساب موجود على الجهاز، سجّل دخول"
        Local.save(p, u, "local_$u", pass)
        startSession(p, u, "local_$u")
        return true to u
    }
    if (Local.verify(p, u, pass)) {
        startSession(p, u, p.getString("acct_uid", "") ?: "")
        return true to u
    }
    return false to "اسم المستخدم أو كلمة السر غلط"
}

// =====================================================
// البصمة
// =====================================================
fun canBio(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun promptBio(act: FragmentActivity, onOk: () -> Unit, onFail: (String) -> Unit) {
    val exec = ContextCompat.getMainExecutor(act)
    val prompt = BiometricPrompt(act, exec, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFail(errString.toString()) }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("محفظتي")
        .setSubtitle("افتح التطبيق ببصمتك")
        .setNegativeButtonText("استخدم كلمة السر")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        .build()
    prompt.authenticate(info)
}

// =====================================================
// Activity
// =====================================================
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        setContent {
            var themeMode by remember { mutableStateOf(prefs.getInt("theme", 0)) }
            WalletTheme(themeMode) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(prefs, themeMode) {
                        themeMode = it
                        prefs.edit().putInt("theme", it).apply()
                    }
                }
            }
        }
    }
}

@Composable
fun Root(prefs: SharedPreferences, themeMode: Int, onTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(prefs.getString("user", null)) }
    var unlocked by remember { mutableStateOf(false) }

    fun logout() {
        prefs.edit().remove("user").remove("uid").remove("refresh").apply()
        Cloud.clear()
        unlocked = false
        user = null
    }

    val u = user
    when {
        u == null -> AuthScreen(prefs) { user = it; unlocked = true }
        prefs.getBoolean("bio", false) && !unlocked -> LockScreen(prefs, { unlocked = true }, ::logout)
        else -> {
            val uid = prefs.getString("uid", "") ?: ""
            val db = remember(u, uid) { Db(ctx, dbNameFor(prefs, uid)) }
            WalletApp(db, prefs, themeMode, onTheme, u, ::logout)
        }
    }
}

fun shareText(ctx: Context, subject: String, text: String, chooser: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(i, chooser))
}

fun exportCsv(ctx: Context, items: List<Tx>) {
    fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    val df = SimpleDateFormat("yyyy/MM/dd", Locale.US)
    val sb = StringBuilder("النوع,المبلغ,الوصف,التصنيف,التاريخ,مسدد\n")
    items.forEach {
        sb.append("${q(it.type.label)},${it.amount},${q(it.title)},${q(it.category)},${df.format(Date(it.date))},${if (it.settled) "نعم" else "لا"}\n")
    }
    shareText(ctx, "بيانات المحفظة", sb.toString(), "تصدير البيانات")
}

// =====================================================
// شاشة تسجيل الدخول / إنشاء حساب
// =====================================================
@Composable
fun AuthScreen(prefs: SharedPreferences, onDone: (String) -> Unit) {
    var signup by remember { mutableStateOf(prefs.getString("acct_user", null) == null) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var showCfg by remember { mutableStateOf(false) }
    var cloud by remember { mutableStateOf(Cloud.on(prefs)) }
    val main = remember { Handler(Looper.getMainLooper()) }

    fun submit() {
        err = ""
        if (signup && pass != pass2) { err = "كلمتا السر غير متطابقتين"; return }
        busy = true
        val s = signup; val u = user; val p = pass
        Thread {
            val (ok, msg) = doAuth(prefs, s, u, p)
            main.post {
                busy = false
                if (ok) onDone(msg) else err = msg
            }
        }.start()
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.linearGradient(listOf(HeaderStart, HeaderEnd)))
            .statusBarsPadding().navigationBarsPadding().imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("محفظتي", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                if (signup) "إنشاء حساب جديد" else "تسجيل الدخول",
                color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(20.dp))
            AppCard(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = user, onValueChange = { user = it }, singleLine = true,
                    label = { Text("اسم المستخدم") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true,
                    label = { Text("كلمة السر") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                if (signup) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = pass2, onValueChange = { pass2 = it }, singleLine = true,
                        label = { Text("تأكيد كلمة السر") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (err.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { submit() }, enabled = !busy,
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Text(if (signup) "إنشاء الحساب" else "دخول")
                }
                TextButton(onClick = { signup = !signup; err = "" }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (signup) "عندي حساب بالفعل؟ سجّل دخول" else "مستخدم جديد؟ أنشئ حساب")
                }
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = { showCfg = true }) {
                Text(
                    if (cloud) "☁ السحابة مفعّلة (تعديل الإعداد)" else "☁ فعّل السحابة لفتح حسابك من أي تلفون",
                    color = Color.White
                )
            }
            if (!cloud) {
                Text(
                    "من غير سحابة الحساب بيتحفظ على الجهاز ده بس.",
                    color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    if (showCfg) {
        CloudCfgDialog(prefs, onDismiss = { showCfg = false; cloud = Cloud.on(prefs) })
    }
}

@Composable
fun CloudCfgDialog(prefs: SharedPreferences, onDismiss: () -> Unit) {
    var key by remember { mutableStateOf(prefs.getString("cfg_key", "") ?: "") }
    var pid by remember { mutableStateOf(prefs.getString("cfg_pid", "") ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("إعداد السحابة (Firebase)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "من Firebase Console ← Project settings: انسخ Web API Key و Project ID. سيبهم فاضيين لو مش عايز سحابة.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = key, onValueChange = { key = it }, singleLine = true,
                    label = { Text("Web API Key") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pid, onValueChange = { pid = it }, singleLine = true,
                    label = { Text("Project ID") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                prefs.edit().putString("cfg_key", key.trim()).putString("cfg_pid", pid.trim()).apply()
                onDismiss()
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// =====================================================
// شاشة القفل (بصمة أو كلمة سر)
// =====================================================
@Composable
fun LockScreen(prefs: SharedPreferences, onUnlock: () -> Unit, onLogout: () -> Unit) {
    val act = LocalContext.current as FragmentActivity
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { promptBio(act, onUnlock) { } }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.linearGradient(listOf(HeaderStart, HeaderEnd)))
            .statusBarsPadding().navigationBarsPadding().imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("محفظتي", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Bold)
            Text("التطبيق مقفول 🔒", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(20.dp))
            AppCard(Modifier.fillMaxWidth()) {
                Button(
                    onClick = { promptBio(act, onUnlock) { } },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                ) { Text("فتح بالبصمة") }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it; err = "" }, singleLine = true,
                    label = { Text("أو اكتب كلمة السر") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                if (err.isNotEmpty()) {
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { if (Local.verifyAny(prefs, pass)) onUnlock() else err = "كلمة السر غلط" },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                ) { Text("فتح") }
                TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
                    Text("تسجيل خروج", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

// =====================================================
// التطبيق الرئيسي
// =====================================================
@Composable
fun WalletApp(
    db: Db, prefs: SharedPreferences, themeMode: Int, onTheme: (Int) -> Unit,
    user: String, onLogout: () -> Unit
) {
    val ctx = LocalContext.current
    val main = remember { Handler(Looper.getMainLooper()) }

    var items by remember { mutableStateOf(db.all()) }
    var budgets by remember { mutableStateOf(db.budgets()) }
    var cur by remember { mutableStateOf(prefs.getString("cur", "ج.س") ?: "ج.س") }
    var decimals by remember { mutableStateOf(prefs.getBoolean("dec", true)) }
    var warn by remember { mutableStateOf(prefs.getInt("warn", 80)) }
    var bioOn by remember { mutableStateOf(prefs.getBoolean("bio", false)) }
    var syncMsg by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var offset by remember { mutableStateOf(0) }
    var showAll by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var showBudget by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    fun runSync() {
        if (!Cloud.on(prefs)) return
        syncMsg = "☁ جاري المزامنة..."
        Thread {
            val (msg, changed) = Cloud.sync(prefs, db)
            main.post {
                syncMsg = msg
                if (changed) { items = db.all(); budgets = db.budgets() }
            }
        }.start()
    }

    val pushTask = remember { Runnable { runSync() } }

    fun refresh() {
        items = db.all()
        budgets = db.budgets()
        if (Cloud.on(prefs)) {
            main.removeCallbacks(pushTask)
            main.postDelayed(pushTask, 1500)
        }
    }

    LaunchedEffect(Unit) { runSync() }

    val keyFmt = remember { SimpleDateFormat("yyyy-MM", Locale.US) }
    val labelFmt = remember { SimpleDateFormat("MMMM yyyy", Locale.forLanguageTag("ar")) }
    val cal = Calendar.getInstance().apply { add(Calendar.MONTH, offset) }
    val key = keyFmt.format(cal.time)
    val monthItems = items.filter { keyFmt.format(Date(it.date)) == key }
    val period = if (showAll) items else monthItems

    val income = period.filter { it.type == Type.INCOME }.sumOf { it.amount }
    val expense = period.filter { it.type == Type.EXPENSE }.sumOf { it.amount }

    // الرصيد: الدخل - المصروف + الديون اللي اتحصّلت - الديون اللي اتسدّدت
    val collected = items.filter { it.type == Type.DEBT_OTHER && it.settled }.sumOf { it.amount }
    val repaid = items.filter { it.type == Type.DEBT_ME && it.settled }.sumOf { it.amount }
    val totalBalance = items.filter { it.type == Type.INCOME }.sumOf { it.amount } -
        items.filter { it.type == Type.EXPENSE }.sumOf { it.amount } + collected - repaid

    val days = if (offset == 0) cal.get(Calendar.DAY_OF_MONTH) else cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    CompositionLocalProvider(LocalCur provides cur, LocalDec provides decimals) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { editing = null; showDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.navigationBarsPadding()
                ) { Text("+", style = MaterialTheme.typography.headlineMedium) }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Header(
                    balance = totalBalance, income = income, expense = expense,
                    label = labelFmt.format(cal.time), all = showAll,
                    onPrev = { offset-- }, onNext = { offset++ },
                    onToggleAll = { showAll = !showAll },
                    onSettings = { showSettings = true }
                )
                TabRow(
                    selectedTabIndex = tab,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    listOf("الملخص", "المعاملات", "الميزانية").forEachIndexed { i, s ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) })
                    }
                }
                when (tab) {
                    0 -> SummaryTab(period, items, days, showAll, warn)
                    1 -> TxTab(
                        period, db, ::refresh,
                        onEdit = { editing = it; showDialog = true }
                    )
                    else -> BudgetTab(
                        budgets,
                        (if (showAll) items.filter { keyFmt.format(Date(it.date)) == keyFmt.format(Date()) } else monthItems)
                            .filter { it.type == Type.EXPENSE }
                            .groupBy { it.category.ifBlank { "غير مصنف" } }
                            .mapValues { e -> e.value.sumOf { it.amount } },
                        onAdd = { showBudget = true },
                        onDelete = { db.delBudget(it); refresh() }
                    )
                }
            }
        }

        if (showDialog) {
            TxDialog(
                initial = editing,
                onDismiss = { showDialog = false },
                onSave = { t, a, title, cat ->
                    val e = editing
                    if (e == null) db.add(t, a, title, cat) else db.update(e.id, t, a, title, cat)
                    refresh(); showDialog = false
                }
            )
        }
        if (showBudget) {
            BudgetDialog(
                onDismiss = { showBudget = false },
                onSave = { c, l -> db.setBudget(c, l); refresh(); showBudget = false }
            )
        }
        if (showSettings) {
            SettingsSheet(
                prefs = prefs,
                user = user,
                cloudOn = Cloud.on(prefs),
                syncMsg = syncMsg,
                onSync = { runSync() },
                bioOn = bioOn,
                bioAvail = canBio(ctx),
                onBio = { want ->
                    if (want) {
                        promptBio(
                            ctx as FragmentActivity,
                            { bioOn = true; prefs.edit().putBoolean("bio", true).apply() },
                            { }
                        )
                    } else {
                        bioOn = false
                        prefs.edit().putBoolean("bio", false).apply()
                    }
                },
                onLogout = { showSettings = false; onLogout() },
                cur = cur,
                onCur = { cur = it; prefs.edit().putString("cur", it).apply() },
                themeMode = themeMode,
                onTheme = onTheme,
                decimals = decimals,
                onDecimals = { decimals = it; prefs.edit().putBoolean("dec", it).apply() },
                warn = warn,
                onWarn = { warn = it; prefs.edit().putInt("warn", it).apply() },
                onExport = { exportCsv(ctx, items) },
                onBackup = { shareText(ctx, "نسخة احتياطية - محفظتي", db.backupJson(), "حفظ النسخة الاحتياطية") },
                onRestore = { text -> val ok = db.restore(text); if (ok) refresh(); ok },
                onClear = { db.clearAll(); refresh() },
                onDismiss = { showSettings = false }
            )
        }
    }
}

// =====================================================
// الهيدر
// =====================================================
@Composable
fun Header(
    balance: Double, income: Double, expense: Double, label: String, all: Boolean,
    onPrev: () -> Unit, onNext: () -> Unit, onToggleAll: () -> Unit, onSettings: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.linearGradient(listOf(HeaderStart, HeaderEnd)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("محفظتي", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = onSettings) {
                Text("⚙ الإعدادات", color = Color.White)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onPrev, enabled = !all) {
                Text("→ السابق", color = Color.White.copy(alpha = if (all) 0.35f else 1f))
            }
            TextButton(onClick = onToggleAll) {
                Text(if (all) "كل الفترات" else label, color = Color.White, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onNext, enabled = !all) {
                Text("التالي ←", color = Color.White.copy(alpha = if (all) 0.35f else 1f))
            }
        }
        Text("الرصيد الكلي", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
        Text(fmt(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniStat("الدخل", fmt(income), Modifier.weight(1f))
            MiniStat("المصروف", fmt(expense), Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(label, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
        Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val shape = RoundedCornerShape(18.dp)
    val elev = CardDefaults.cardElevation(defaultElevation = 1.dp)
    if (onClick == null) {
        Card(modifier = modifier, shape = shape, colors = colors, elevation = elev) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, elevation = elev) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

// =====================================================
// شاشة الإعدادات (Bottom Sheet)
// =====================================================
@Composable
fun SettingsSheet(
    prefs: SharedPreferences,
    user: String, cloudOn: Boolean, syncMsg: String, onSync: () -> Unit,
    bioOn: Boolean, bioAvail: Boolean, onBio: (Boolean) -> Unit, onLogout: () -> Unit,
    cur: String, onCur: (String) -> Unit,
    themeMode: Int, onTheme: (Int) -> Unit,
    decimals: Boolean, onDecimals: (Boolean) -> Unit,
    warn: Int, onWarn: (Int) -> Unit,
    onExport: () -> Unit, onBackup: () -> Unit, onRestore: (String) -> Boolean,
    onClear: () -> Unit, onDismiss: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }
    var showRestore by remember { mutableStateOf(false) }
    var showCfg by remember { mutableStateOf(false) }
    var restoreText by remember { mutableStateOf("") }
    var restoreErr by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.background
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("الإعدادات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                // ----- الحساب -----
                AppCard(Modifier.fillMaxWidth()) {
                    Text("الحساب: @$user", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    if (cloudOn) {
                        Text(
                            syncMsg.ifEmpty { "☁ السحابة مفعّلة" },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = onSync, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Text("مزامنة الآن")
                        }
                    } else {
                        Text(
                            "الحساب محلي على الجهاز فقط. فعّل السحابة عشان تفتح حسابك من تلفون تاني.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(onClick = { showCfg = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("إعداد السحابة")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("القفل بالبصمة", fontWeight = FontWeight.SemiBold)
                            Text(
                                if (bioAvail) "اطلب البصمة كل ما تفتح التطبيق" else "مفيش بصمة مسجلة على الجهاز",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = bioOn, onCheckedChange = onBio, enabled = bioAvail)
                    }
                    OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("تسجيل خروج", color = MaterialTheme.colorScheme.error)
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Text("العملة", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Currencies.forEach { (sym, name) ->
                            FilterChip(selected = cur == sym, onClick = { onCur(sym) }, label = { Text("$name ($sym)") })
                        }
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Text("المظهر", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ThemeLabels.forEachIndexed { i, s ->
                            FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(s) })
                        }
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("إظهار الكسور العشرية", fontWeight = FontWeight.SemiBold)
                            Text(
                                "اقفلها لو مبالغك كبيرة وبدون قروش",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = decimals, onCheckedChange = onDecimals)
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Text("حد تحذير نسبة الصرف: $warn%", fontWeight = FontWeight.SemiBold)
                    Text(
                        "لما نسبة الصرف من الدخل توصل للحد ده بيتحول اللون للأحمر",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = warn.toFloat(),
                        onValueChange = { onWarn(it.toInt()) },
                        valueRange = 50f..100f,
                        steps = 9
                    )
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Text("النسخ الاحتياطي والتصدير", fontWeight = FontWeight.SemiBold)
                    Text(
                        "نسخة يدوية تبعتها لنفسك على واتساب أو إيميل، وتسترجعها في أي تلفون.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onBackup, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("حفظ نسخة احتياطية (إرسال)")
                    }
                    OutlinedButton(
                        onClick = { restoreText = ""; restoreErr = false; showRestore = true },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                    ) { Text("استرجاع من نسخة احتياطية") }
                    OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("تصدير CSV (للإكسل)")
                    }
                    if (info.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(info, color = Green)
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Text("مسح كل البيانات", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                    Text(
                        "هيمسح كل المعاملات والميزانيات (وهيتمسح من السحابة كمان لو مفعّلة).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { confirmClear = true }, shape = RoundedCornerShape(12.dp)) {
                        Text("مسح", color = MaterialTheme.colorScheme.error)
                    }
                }

                Text(
                    "محفظتي • النسخة 3.0",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(4.dp)
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showCfg) {
        CloudCfgDialog(prefs, onDismiss = { showCfg = false })
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("متأكد؟") },
            text = { Text("كل البيانات هتتمسح ومينفعش ترجع.") },
            confirmButton = {
                TextButton(onClick = { onClear(); confirmClear = false; info = "" }) {
                    Text("امسح", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("إلغاء") } }
        )
    }

    if (showRestore) {
        AlertDialog(
            onDismissRequest = { showRestore = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("استرجاع نسخة احتياطية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "الصق نص النسخة الاحتياطية هنا. الاسترجاع بيستبدل البيانات الحالية.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = restoreText,
                        onValueChange = { restoreText = it; restoreErr = false },
                        label = { Text("نص النسخة") },
                        minLines = 4, maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(onClick = { clip.getText()?.text?.let { restoreText = it; restoreErr = false } }) {
                        Text("لصق من الحافظة")
                    }
                    if (restoreErr) {
                        Text("النص غير صالح، اتأكد إنك نسخته كامل.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (onRestore(restoreText)) {
                        showRestore = false
                        info = "تم استرجاع البيانات ✔"
                    } else restoreErr = true
                }) { Text("استرجاع") }
            },
            dismissButton = { TextButton(onClick = { showRestore = false }) { Text("إلغاء") } }
        )
    }
}

// =====================================================
// تبويب الملخص
// =====================================================
@Composable
fun SummaryTab(period: List<Tx>, all: List<Tx>, days: Int, isAll: Boolean, warn: Int) {
    val income = period.filter { it.type == Type.INCOME }.sumOf { it.amount }
    val expense = period.filter { it.type == Type.EXPENSE }.sumOf { it.amount }
    val ratio = if (income > 0) (expense / income).toFloat() else if (expense > 0) 1f else 0f
    val (ratioColor, ratioMsg) = when {
        ratio < 0.5f -> Green to "ممتاز 👌 صرفك أقل من نص دخلك"
        ratio * 100 < warn -> Amber to "انتبه ⚠ صرفك بيقرب من حد التحذير ($warn%)"
        ratio <= 1f -> Red to "خطر 🚨 وصلت لحد التحذير أو تعدّيته"
        else -> Red to "🚨 صرفت أكتر من دخلك"
    }
    val saved = income - expense
    val savingRate = if (income > 0) (saved / income * 100).toInt() else 0

    val iOwe = all.filter { it.type == Type.DEBT_ME && !it.settled }.sumOf { it.amount }
    val owedToMe = all.filter { it.type == Type.DEBT_OTHER && !it.settled }.sumOf { it.amount }
    val collected = all.filter { it.type == Type.DEBT_OTHER && it.settled }.sumOf { it.amount }
    val repaid = all.filter { it.type == Type.DEBT_ME && it.settled }.sumOf { it.amount }

    val byCat = period.filter { it.type == Type.EXPENSE }
        .groupBy { it.category.ifBlank { "غير مصنف" } }
        .mapValues { e -> e.value.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }
    val biggest = period.filter { it.type == Type.EXPENSE }.maxByOrNull { it.amount }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("نسبة الصرف من الدخل", fontWeight = FontWeight.SemiBold)
                    Text("${(ratio * 100).toInt()}%", color = ratioColor, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { ratio.coerceIn(0f, 1f) },
                    color = ratioColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))
                )
                Spacer(Modifier.height(8.dp))
                Text(ratioMsg, color = ratioColor, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("المدخرات", fmt(saved), if (saved >= 0) Green else Red, Modifier.weight(1f))
                StatCard("نسبة الادخار", "$savingRate%", MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("ديون عليّ (متبقي)", fmt(iOwe), Amber, Modifier.weight(1f))
                StatCard("مستحقات ليّ (متبقي)", fmt(owedToMe), Blue, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("اتحصّل من المدينين", "+" + fmt(collected), Green, Modifier.weight(1f))
                StatCard("اتسدّد من ديوني", "-" + fmt(repaid), Red, Modifier.weight(1f))
            }
        }
        if (!isAll && expense > 0) {
            item {
                StatCard("متوسط الصرف اليومي", fmt(expense / days), MaterialTheme.colorScheme.onSurface, Modifier.fillMaxWidth())
            }
        }
        if (biggest != null) {
            item {
                StatCard(
                    "أكبر مصروف",
                    "${biggest.title.ifBlank { biggest.category.ifBlank { "—" } }}: ${fmt(biggest.amount)}",
                    Red, Modifier.fillMaxWidth()
                )
            }
        }
        if (byCat.isNotEmpty()) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("المصروفات حسب التصنيف", fontWeight = FontWeight.SemiBold)
                    byCat.forEach { (cat, sum) ->
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(cat); Text(fmt(sum), fontWeight = FontWeight.Medium)
                        }
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { if (expense > 0) (sum / expense).toFloat() else 0f },
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
        }
        if (period.isEmpty()) {
            item {
                Text(
                    "مفيش معاملات في الفترة دي. اضغط + للإضافة.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    AppCard(modifier) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor, fontWeight = FontWeight.Bold)
    }
}

// =====================================================
// تبويب المعاملات
// =====================================================
@Composable
fun TxTab(period: List<Tx>, db: Db, refresh: () -> Unit, onEdit: (Tx) -> Unit) {
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<Type?>(null) }
    val df = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
    val shown = period.filter {
        (filter == null || it.type == filter) &&
            (q.isBlank() || it.title.contains(q, true) || it.category.contains(q, true))
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("بحث") }, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("الكل") })
                Type.values().forEach {
                    FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it.label) })
                }
            }
        }
        if (shown.isEmpty()) {
            item { Text("لا توجد معاملات", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
        }
        items(shown, key = { it.id }) { t ->
            AppCard(Modifier.fillMaxWidth(), onClick = { onEdit(t) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(t.type.color()))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title.ifBlank { t.type.label }, fontWeight = FontWeight.SemiBold)
                        val doneLabel = if (t.type == Type.DEBT_OTHER) " • ✔ تم التحصيل" else " • ✔ تم السداد"
                        Text(
                            "${t.type.label} • ${t.category.ifBlank { "—" }} • ${df.format(Date(t.date))}" +
                                if (t.settled) doneLabel else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // الدين المفتوح مالوش علامة، ولما يتسدد أو يتحصّل بيأثر على الرصيد
                    val sign = when {
                        t.type == Type.INCOME -> "+"
                        t.type == Type.EXPENSE -> "-"
                        t.type == Type.DEBT_OTHER && t.settled -> "+"
                        t.type == Type.DEBT_ME && t.settled -> "-"
                        else -> ""
                    }
                    Text("$sign${fmt(t.amount)}", color = t.type.color(), fontWeight = FontWeight.Bold)
                }
                Row {
                    if (t.type == Type.DEBT_ME || t.type == Type.DEBT_OTHER) {
                        val isOwedToMe = t.type == Type.DEBT_OTHER
                        TextButton(onClick = { db.setSettled(t.id, !t.settled); refresh() }) {
                            Text(
                                when {
                                    isOwedToMe && t.settled -> "إلغاء التحصيل"
                                    isOwedToMe -> "تم التحصيل"
                                    t.settled -> "إلغاء السداد"
                                    else -> "تم السداد"
                                }
                            )
                        }
                    }
                    TextButton(onClick = { onEdit(t) }) { Text("تعديل") }
                    TextButton(onClick = { db.delete(t.id); refresh() }) {
                        Text("حذف", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// =====================================================
// تبويب الميزانية
// =====================================================
@Composable
fun BudgetTab(
    budgets: Map<String, Double>, spent: Map<String, Double>,
    onAdd: () -> Unit, onDelete: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("+ إضافة / تعديل ميزانية تصنيف")
            }
        }
        if (budgets.isEmpty()) {
            item {
                Text(
                    "حدد حد شهري لكل تصنيف (مثلًا أكل 2000) وهتتنبه لما تقرب منه.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(budgets.toList(), key = { it.first }) { (cat, limit) ->
            val s = spent[cat] ?: 0.0
            val r = if (limit > 0) (s / limit).toFloat() else 0f
            val c = when { r < 0.8f -> Green; r < 1f -> Amber; else -> Red }
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(cat, fontWeight = FontWeight.SemiBold)
                    Text("${(r * 100).toInt()}%", color = c, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { r.coerceIn(0f, 1f) }, color = c,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "صرفت ${fmt(s)} من ${fmt(limit)}" +
                        if (r >= 1f) " — تجاوزت الميزانية!" else "",
                    style = MaterialTheme.typography.bodySmall, color = c
                )
                TextButton(onClick = { onDelete(cat) }) {
                    Text("حذف الميزانية", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

// =====================================================
// نافذة إضافة / تعديل معاملة
// =====================================================
@Composable
fun TxDialog(initial: Tx?, onDismiss: () -> Unit, onSave: (Type, Double, String, String) -> Unit) {
    var type by remember { mutableStateOf(initial?.type ?: Type.EXPENSE) }
    var amount by remember {
        mutableStateOf(
            initial?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""
        )
    }
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var cat by remember { mutableStateOf(initial?.category ?: "") }
    val isDebt = type == Type.DEBT_ME || type == Type.DEBT_OTHER

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "إضافة معاملة" else "تعديل المعاملة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Type.values().forEach {
                        FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it.label) })
                    }
                }
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it }, label = { Text("المبلغ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                )
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(if (isDebt) "اسم الشخص" else "الوصف") }, singleLine = true
                )
                if (!isDebt) {
                    val cats = if (type == Type.INCOME) IncomeCats else ExpenseCats
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        cats.forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                        }
                    }
                    OutlinedTextField(
                        value = cat, onValueChange = { cat = it },
                        label = { Text("التصنيف") }, singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.replace(",", ".").toDoubleOrNull()
                if (a != null && a > 0) onSave(type, a, title.trim(), if (isDebt) "" else cat.trim())
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// =====================================================
// نافذة الميزانية
// =====================================================
@Composable
fun BudgetDialog(onDismiss: () -> Unit, onSave: (String, Double) -> Unit) {
    var cat by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("ميزانية شهرية") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpenseCats.forEach { c ->
                        FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                    }
                }
                OutlinedTextField(
                    value = cat, onValueChange = { cat = it },
                    label = { Text("التصنيف") }, singleLine = true
                )
                OutlinedTextField(
                    value = limit, onValueChange = { limit = it }, label = { Text("الحد الشهري") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val l = limit.replace(",", ".").toDoubleOrNull()
                if (cat.isNotBlank() && l != null && l > 0) onSave(cat.trim(), l)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
